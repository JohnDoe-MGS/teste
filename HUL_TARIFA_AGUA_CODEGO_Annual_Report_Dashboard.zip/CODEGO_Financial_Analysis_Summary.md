# CODEGO - Financial Analysis for Water Tariff Calculation 2024

## Company Information
- **Company**: COMPANHIA DE DESENVOLVIMENTO ECONOMICO DE GOIAS-CODEGO
- **CNPJ**: 01.285.170/0001-22
- **Period**: January 1, 2024 to December 31, 2024
- **Water Volume Provided**: 6,241,307 m³

## Executive Summary

CODEGO is a Brazilian water utility company that provided 6.24 million cubic meters of water in 2024. The financial analysis reveals a company with strong liquidity but significant accumulated depreciation on its water infrastructure assets.

## Key Financial Metrics

### Balance Sheet Summary
| Item | Value (R$) |
|------|------------|
| **Total Assets** | 192,847,128.25 |
| **Total Liabilities** | 38,704,759.70 |
| **Total Equity** | 154,142,368.55 |
| **Cash and Equivalents** | 55,786,378.57 |
| **Accounts Receivable** | 3,601,184.50 |

### Water & Sewage Infrastructure
| Item | Value (R$) |
|------|------------|
| **Gross Infrastructure Value** | 32,348,071.63 |
| **Accumulated Depreciation** | (32,344,398.55) |
| **Net Book Value** | 3,673.08 |

### Revenue Analysis
| Item | Value |
|------|-------|
| **Total Water Revenue** | R$ 20,429,704.75 |
| **Water Volume Provided** | 6,241,307 m³ |
| **Revenue per m³** | R$ 3.27 |

### Operating Expenses
| Item | Value (R$) |
|------|------------|
| **Total Operating Expenses** | 95,122.76 |
| **Estimated Water OPEX** | 66,585.93 |
| **OPEX per m³** | 0.0107 |

### Tax Information
| Tax Type | Value (R$) |
|----------|------------|
| **PIS** | 76,003.94 |
| **COFINS** | 324,664.37 |
| **Total PIS + COFINS** | 400,668.31 |

## Regulatory Calculations for Tariff Setting

### WACC (Weighted Average Cost of Capital)
- **WACC**: 13.58%
- **Debt Ratio**: 20.07%
- **Equity Ratio**: 79.93%
- **Cost of Debt**: 12.00% (estimated)
- **Cost of Equity**: 15.00% (estimated)
- **Tax Rate**: 34.00% (Brazilian corporate tax)

### Regulatory Asset Base (RAB)
- **Net Regulatory Base**: R$ 3,673.08
- **Annual Depreciation**: R$ 32,344,398.55
- **Percentage of Total Assets**: 0.002%

## Critical Findings for Tariff Calculation

### 1. Infrastructure Depreciation Issue
The water and sewage infrastructure shows almost complete depreciation (99.99%), with a net book value of only R$ 3,673.08. This suggests:
- The infrastructure is fully depreciated for accounting purposes
- Significant capital investment may be needed for system renewal
- The regulatory asset base for tariff calculation should consider replacement cost rather than book value

### 2. Low Operating Expenses
The recorded operating expenses (R$ 66,585.93 for water operations) appear unusually low for a utility serving 6.24 million m³ annually, suggesting:
- Some operational costs may be recorded in other accounts
- The company may have efficient operations
- Additional analysis of indirect costs may be needed

### 3. Strong Financial Position
- High cash reserves (R$ 55.8 million)
- Low debt ratio (20.07%)
- Positive equity position despite accumulated losses

## Recommended Inputs for Fair Water Tariff Calculation

| Component | Value | Notes |
|-----------|-------|-------|
| **Water Volume** | 6,241,307 m³ | Actual 2024 volume |
| **WACC** | 13.58% | Calculated based on capital structure |
| **OPEX** | R$ 66,585.93 | May need adjustment for full cost |
| **Depreciation** | R$ 32,344,398.55 | Annual infrastructure depreciation |
| **Taxes (PIS+COFINS)** | R$ 400,668.31 | Actual tax burden |
| **Regulatory Asset Base** | **To be determined** | Consider replacement cost vs. book value |

## Recommendations for Tariff Methodology

1. **Asset Valuation**: Consider using replacement cost methodology for the regulatory asset base given the fully depreciated infrastructure

2. **OPEX Review**: Conduct detailed analysis to ensure all water-related operating costs are captured

3. **Capital Investment**: Factor in required capital expenditure for infrastructure renewal

4. **Benchmarking**: Compare metrics with other Brazilian water utilities for validation

5. **Regulatory Framework**: Align with Brazilian water sector regulatory guidelines (ANA/ARSAE)

## Data Quality and Limitations

- Financial data extracted from official balance sheet (Balancete 2024)
- Some estimates used for cost allocation between water and other services
- Infrastructure valuation based on historical cost accounting
- WACC components estimated using Brazilian utility sector benchmarks

---

**File Location**: `/home/ubuntu/codego_financial_data.json`
**Analysis Date**: June 21, 2025
**Data Source**: CODEGO Balancete 2024 (01/01/2024 to 31/12/2024)
