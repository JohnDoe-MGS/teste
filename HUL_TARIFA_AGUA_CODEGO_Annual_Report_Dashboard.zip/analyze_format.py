#!/usr/bin/env python3
"""
Analyze the actual format of the CODEGO balance sheet
"""

def read_pdf_content_safe(file_path: str) -> str:
    """Read the PDF content with proper encoding handling"""
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    
    # If all encodings fail, read as binary and decode with errors='ignore'
    with open(file_path, 'rb') as f:
        return f.read().decode('utf-8', errors='ignore')

def analyze_lines():
    content = read_pdf_content_safe('/home/ubuntu/Uploads/Balancete122024.pdf')
    lines = content.split('\n')
    
    print("=== ANALYZING BALANCE SHEET FORMAT ===")
    print("Looking for lines with account codes and financial data...\n")
    
    account_lines = []
    for i, line in enumerate(lines[:100]):  # First 100 lines
        line = line.strip()
        if not line:
            continue
            
        # Look for lines that start with numbers and contain financial data
        if line and (line[0].isdigit() or line.startswith('1-') or line.startswith('2-') or line.startswith('3-') or line.startswith('4-')):
            print(f"Line {i+1}: {line}")
            account_lines.append(line)
    
    print(f"\nFound {len(account_lines)} potential account lines in first 100 lines")
    
    # Look for specific patterns
    print("\n=== LOOKING FOR KEY FINANCIAL ITEMS ===")
    key_terms = ['ATIVO', 'PASSIVO', 'RECEITA', 'DESPESA', 'CAIXA', 'BANCO']
    
    for term in key_terms:
        matching_lines = [line for line in lines if term in line.upper()]
        print(f"\nLines containing '{term}': {len(matching_lines)}")
        for line in matching_lines[:3]:  # Show first 3 matches
            print(f"  {line.strip()}")

if __name__ == "__main__":
    analyze_lines()
