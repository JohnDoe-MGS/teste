
'use client';

import { useState, useEffect } from 'react';
import Sidebar from '@/components/sidebar';
import TariffCalculator from '@/components/tariff-calculator';
import FinancialDataDisplay from '@/components/financial-data-display';
import SensitivityAnalysis from '@/components/sensitivity-analysis';
import CostBreakdownChart from '@/components/cost-breakdown-chart';
import TariffComparisonChart from '@/components/tariff-comparison-chart';
import { FinancialData, TariffInputs } from '@/lib/types';
import { calculateFairTariff } from '@/lib/calculations';

export default function Dashboard() {
  const [activeSection, setActiveSection] = useState('calculator');
  const [financialData, setFinancialData] = useState<FinancialData | null>(null);
  const [tariffInputs, setTariffInputs] = useState<TariffInputs | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load financial data
    const loadData = async () => {
      try {
        const response = await fetch('/data/codego_financial_data.json');
        const data: FinancialData = await response.json();
        setFinancialData(data);

        // Initialize tariff inputs from financial data
        const inputs: TariffInputs = {
          wacc: data.tariff_calculation_inputs.wacc_to_calculate,
          regulatoryAssetBase: data.tariff_calculation_inputs.net_regulatory_base,
          opex: data.tariff_calculation_inputs.water_opex,
          taxes: data.tariff_calculation_inputs.pis_cofins,
          depreciation: data.tariff_calculation_inputs.annual_depreciation,
          waterVolume: data.tariff_calculation_inputs.water_volume_m3,
          currentTariff: 0, // To be filled by user
        };
        setTariffInputs(inputs);
      } catch (error) {
        console.error('Error loading financial data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando dados financeiros...</p>
        </div>
      </div>
    );
  }

  if (!financialData || !tariffInputs) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Erro ao carregar os dados financeiros</p>
        </div>
      </div>
    );
  }

  const calculation = calculateFairTariff(tariffInputs);

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      
      <main className="md:ml-64 min-h-screen">
        <div className="p-6">
          <header className="mb-8">
            <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg shadow-lg">
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                Calculadora de Tarifa de Água Justa 2024
              </h1>
              <p className="text-blue-100">
                Análise regulatória baseada nos dados financeiros da CODEGO
              </p>
            </div>
          </header>

          {activeSection === 'calculator' && (
            <div className="space-y-6">
              <TariffCalculator initialData={tariffInputs} />
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <CostBreakdownChart 
                  calculation={calculation} 
                  waterVolume={tariffInputs.waterVolume} 
                />
                <TariffComparisonChart 
                  fairTariff={calculation.fairTariff}
                  currentTariff={tariffInputs.currentTariff}
                />
              </div>
            </div>
          )}

          {activeSection === 'financial' && (
            <FinancialDataDisplay data={financialData} />
          )}

          {activeSection === 'sensitivity' && (
            <SensitivityAnalysis baseInputs={tariffInputs} />
          )}

          {activeSection === 'comparison' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <TariffComparisonChart 
                fairTariff={calculation.fairTariff}
                currentTariff={tariffInputs.currentTariff}
              />
              <CostBreakdownChart 
                calculation={calculation} 
                waterVolume={tariffInputs.waterVolume} 
              />
            </div>
          )}
        </div>

        <footer className="mt-12 p-6 bg-white border-t">
          <div className="max-w-4xl mx-auto text-center text-sm text-gray-600">
            <p className="mb-2">
              <strong>Metodologia:</strong> Tarifa Justa = (WACC × Base Regulatória + OPEX + Impostos + Depreciação) ÷ Volume de Água
            </p>
            <p>
              Baseado nos dados financeiros da CODEGO para o período de {financialData.company_info.period}
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
}
