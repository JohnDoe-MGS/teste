
'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { TariffCalculation } from '@/lib/types';
import { formatCurrency } from '@/lib/calculations';

interface CostBreakdownChartProps {
  calculation: TariffCalculation;
  waterVolume: number;
}

const COLORS = ['#60B5FF', '#FF9149', '#FF9898', '#80D8C3'];

export default function CostBreakdownChart({ calculation, waterVolume }: CostBreakdownChartProps) {
  const data = [
    {
      name: 'Retorno WACC',
      value: calculation.costBreakdown.waccReturn,
      percentage: (calculation.costBreakdown.waccReturn / calculation.totalCosts) * 100,
    },
    {
      name: 'OPEX',
      value: calculation.costBreakdown.opex,
      percentage: (calculation.costBreakdown.opex / calculation.totalCosts) * 100,
    },
    {
      name: 'Impostos',
      value: calculation.costBreakdown.taxes,
      percentage: (calculation.costBreakdown.taxes / calculation.totalCosts) * 100,
    },
    {
      name: 'Depreciação',
      value: calculation.costBreakdown.depreciation,
      percentage: (calculation.costBreakdown.depreciation / calculation.totalCosts) * 100,
    },
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border text-sm">
          <p className="font-medium">{data.name}</p>
          <p className="text-blue-600">Valor: {formatCurrency(data.value)}</p>
          <p className="text-gray-600">Por m³: {formatCurrency(data.value / waterVolume)}</p>
          <p className="text-gray-600">Percentual: {data.percentage.toFixed(1)}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Composição dos Custos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={120}
                paddingAngle={5}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                verticalAlign="top"
                wrapperStyle={{ fontSize: 11 }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
