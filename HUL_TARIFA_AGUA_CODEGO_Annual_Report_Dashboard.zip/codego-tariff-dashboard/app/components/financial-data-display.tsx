
'use client';

import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { FinancialData } from '@/lib/types';
import { formatCurrency, formatNumber, formatPercentage } from '@/lib/calculations';
import { Building, TrendingDown, Calculator, Droplets } from 'lucide-react';

interface FinancialDataDisplayProps {
  data: FinancialData;
}

export default function FinancialDataDisplay({ data }: FinancialDataDisplayProps) {
  const infrastructure = data.water_sewage_operations.infrastructure.water_supply_system;
  const operations = data.water_sewage_operations.operations;
  const inputs = data.tariff_calculation_inputs;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Informações da Empresa
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Nome da Empresa</p>
              <p className="font-medium">{data.company_info.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">CNPJ</p>
              <p className="font-medium">{data.company_info.cnpj}</p>
            </div>
            <div className="md:col-span-2">
              <p className="text-sm text-gray-600">Período de Análise</p>
              <p className="font-medium">{data.company_info.period}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5" />
              Infraestrutura de Água e Esgoto
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Valor Bruto dos Ativos</p>
              <p className="text-xl font-bold text-blue-600">
                {formatCurrency(infrastructure.gross_value)}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Depreciação Acumulada</p>
              <p className="text-xl font-bold text-red-600">
                {formatCurrency(Math.abs(infrastructure.accumulated_depreciation))}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Valor Líquido Contábil</p>
              <p className="text-xl font-bold text-green-600">
                {formatCurrency(infrastructure.net_book_value)}
              </p>
            </div>
            <div className="mt-4 p-3 bg-yellow-50 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Observação:</strong> Os ativos estão 99,99% depreciados, indicando necessidade de reposição/reavaliação.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Droplets className="h-5 w-5" />
              Operações de Água
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Volume Fornecido Anual</p>
              <p className="text-xl font-bold text-blue-600">
                {formatNumber(operations.water_volume_provided_m3, 0)} m³
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Receita por m³</p>
              <p className="text-xl font-bold text-green-600">
                {formatCurrency(operations.revenue_per_m3)}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">OPEX por m³</p>
              <p className="text-xl font-bold text-orange-600">
                {formatCurrency(operations.opex_per_m3)}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Parâmetros para Cálculo da Tarifa
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Parâmetro</th>
                  <th className="text-right py-2">Valor</th>
                  <th className="text-left py-2">Observações</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2">WACC</td>
                  <td className="text-right font-mono">{formatPercentage(inputs.wacc_to_calculate)}</td>
                  <td className="text-gray-600">Custo médio ponderado de capital</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Base Regulatória</td>
                  <td className="text-right font-mono">{formatCurrency(inputs.net_regulatory_base)}</td>
                  <td className="text-gray-600">Valor líquido dos ativos regulatórios</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">OPEX Água</td>
                  <td className="text-right font-mono">{formatCurrency(inputs.water_opex)}</td>
                  <td className="text-gray-600">Despesas operacionais relacionadas à água</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">PIS + COFINS</td>
                  <td className="text-right font-mono">{formatCurrency(inputs.pis_cofins)}</td>
                  <td className="text-gray-600">Impostos federais</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Depreciação Anual</td>
                  <td className="text-right font-mono">{formatCurrency(inputs.annual_depreciation)}</td>
                  <td className="text-gray-600">Valor da depreciação dos ativos</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Volume de Água</td>
                  <td className="text-right font-mono">{formatNumber(inputs.water_volume_m3, 0)} m³</td>
                  <td className="text-gray-600">Volume anual fornecido</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
