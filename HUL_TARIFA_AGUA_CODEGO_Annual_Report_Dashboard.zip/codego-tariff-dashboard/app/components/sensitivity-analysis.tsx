
'use client';

import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { TariffInputs } from '@/lib/types';
import { calculateFairTariff, formatCurrency } from '@/lib/calculations';

interface SensitivityAnalysisProps {
  baseInputs: TariffInputs;
}

export default function SensitivityAnalysis({ baseInputs }: SensitivityAnalysisProps) {
  const [selectedVariable, setSelectedVariable] = useState('wacc');

  const variables = [
    { id: 'wacc', label: 'WACC', unit: '%', baseValue: baseInputs.wacc * 100 },
    { id: 'regulatoryAssetBase', label: 'Base Regulatória', unit: 'R$', baseValue: baseInputs.regulatoryAssetBase },
    { id: 'opex', label: 'OPEX', unit: 'R$', baseValue: baseInputs.opex },
    { id: 'waterVolume', label: 'Volume de Água', unit: 'm³', baseValue: baseInputs.waterVolume },
  ];

  const generateSensitivityData = (variableId: string) => {
    const baseVariable = variables.find(v => v.id === variableId);
    if (!baseVariable) return [];

    const variations = [-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50];
    
    return variations.map(variation => {
      const newInputs = { ...baseInputs };
      const factor = 1 + (variation / 100);
      
      if (variableId === 'wacc') {
        newInputs.wacc = baseInputs.wacc * factor;
      } else if (variableId === 'regulatoryAssetBase') {
        newInputs.regulatoryAssetBase = baseInputs.regulatoryAssetBase * factor;
      } else if (variableId === 'opex') {
        newInputs.opex = baseInputs.opex * factor;
      } else if (variableId === 'waterVolume') {
        newInputs.waterVolume = baseInputs.waterVolume * factor;
      }

      const calculation = calculateFairTariff(newInputs);

      return {
        variation: `${variation >= 0 ? '+' : ''}${variation}%`,
        variationValue: variation,
        tariff: calculation.fairTariff,
        variableValue: variableId === 'wacc' ? newInputs.wacc * 100 : newInputs[variableId as keyof TariffInputs],
      };
    });
  };

  const data = generateSensitivityData(selectedVariable);
  const selectedVar = variables.find(v => v.id === selectedVariable);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const point = payload[0].payload;
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border text-sm">
          <p className="font-medium">Variação: {label}</p>
          <p className="text-blue-600">Tarifa: {formatCurrency(point.tariff)}</p>
          <p className="text-gray-600">
            {selectedVar?.label}: {point.variableValue.toLocaleString('pt-BR')} {selectedVar?.unit}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Análise de Sensibilidade</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2">
              Selecione a variável para análise:
            </label>
            <Select value={selectedVariable} onValueChange={setSelectedVariable}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {variables.map(variable => (
                  <SelectItem key={variable.id} value={variable.id}>
                    {variable.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={data}
                margin={{ top: 20, right: 30, left: 40, bottom: 40 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="variation"
                  tickLine={false}
                  tick={{ fontSize: 10 }}
                  label={{ 
                    value: 'Variação da Variável', 
                    position: 'insideBottom', 
                    offset: -15,
                    style: { textAnchor: 'middle', fontSize: 11 } 
                  }}
                />
                <YAxis 
                  tickLine={false}
                  tick={{ fontSize: 10 }}
                  tickFormatter={(value) => `R$ ${value.toFixed(2)}`}
                  label={{ 
                    value: 'Tarifa (R$/m³)', 
                    angle: -90, 
                    position: 'insideLeft',
                    style: { textAnchor: 'middle', fontSize: 11 } 
                  }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="tariff" 
                  stroke="#60B5FF" 
                  strokeWidth={3}
                  dot={{ fill: '#60B5FF', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: '#60B5FF', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">Interpretação:</h4>
            <p className="text-sm text-blue-800">
              Este gráfico mostra como a tarifa justa varia conforme mudanças na {selectedVar?.label.toLowerCase()}. 
              Cada ponto representa uma variação de -50% a +50% em relação ao valor base de{' '}
              {selectedVar?.baseValue.toLocaleString('pt-BR')} {selectedVar?.unit}.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
