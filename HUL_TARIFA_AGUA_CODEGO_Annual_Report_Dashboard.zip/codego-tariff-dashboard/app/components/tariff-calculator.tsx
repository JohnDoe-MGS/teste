
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { RotateCcw } from 'lucide-react';
import { TariffInputs, TariffCalculation } from '@/lib/types';
import { calculateFairTariff, formatCurrency, formatNumber, formatPercentage } from '@/lib/calculations';

interface TariffCalculatorProps {
  initialData: TariffInputs;
}

export default function TariffCalculator({ initialData }: TariffCalculatorProps) {
  const [inputs, setInputs] = useState<TariffInputs>(initialData);
  const [calculation, setCalculation] = useState<TariffCalculation>();

  useEffect(() => {
    setCalculation(calculateFairTariff(inputs));
  }, [inputs]);

  const handleInputChange = (field: keyof TariffInputs, value: string) => {
    const numValue = parseFloat(value) || 0;
    setInputs(prev => ({ ...prev, [field]: numValue }));
  };

  const handleReset = () => {
    setInputs(initialData);
  };

  const difference = calculation ? calculation.fairTariff - inputs.currentTariff : 0;
  const percentageDiff = inputs.currentTariff > 0 ? (difference / inputs.currentTariff) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Formula Display */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Fórmula da Tarifa Justa
            <Button variant="outline" size="sm" onClick={handleReset}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Resetar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-blue-50 p-4 rounded-lg font-mono text-sm">
            <p className="text-center">
              <strong>Tarifa Justa = (WACC × Base Regulatória + OPEX + Impostos + Depreciação) ÷ Volume de Água</strong>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Input Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Parâmetros Financeiros</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="wacc">WACC (%)</Label>
              <Input
                id="wacc"
                type="number"
                step="0.0001"
                value={inputs.wacc * 100}
                onChange={(e) => handleInputChange('wacc', ((parseFloat(e.target.value) || 0) / 100).toString())}
              />
            </div>
            <div>
              <Label htmlFor="regulatoryAssetBase">Base Regulatória (R$)</Label>
              <Input
                id="regulatoryAssetBase"
                type="number"
                step="0.01"
                value={inputs.regulatoryAssetBase}
                onChange={(e) => handleInputChange('regulatoryAssetBase', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="opex">OPEX - Despesas Operacionais (R$)</Label>
              <Input
                id="opex"
                type="number"
                step="0.01"
                value={inputs.opex}
                onChange={(e) => handleInputChange('opex', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Custos e Volume</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="taxes">Impostos - PIS + COFINS (R$)</Label>
              <Input
                id="taxes"
                type="number"
                step="0.01"
                value={inputs.taxes}
                onChange={(e) => handleInputChange('taxes', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="depreciation">Depreciação Anual (R$)</Label>
              <Input
                id="depreciation"
                type="number"
                step="0.01"
                value={inputs.depreciation}
                onChange={(e) => handleInputChange('depreciation', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="waterVolume">Volume de Água (m³)</Label>
              <Input
                id="waterVolume"
                type="number"
                value={inputs.waterVolume}
                onChange={(e) => handleInputChange('waterVolume', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Tariff Input */}
      <Card>
        <CardHeader>
          <CardTitle>Tarifa Atual da CODEGO</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-w-md">
            <Label htmlFor="currentTariff">Tarifa Atual (R$/m³)</Label>
            <Input
              id="currentTariff"
              type="number"
              step="0.001"
              value={inputs.currentTariff}
              onChange={(e) => handleInputChange('currentTariff', e.target.value)}
              placeholder="Digite a tarifa atual da CODEGO"
            />
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {calculation && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="text-green-700">Tarifa Justa Calculada</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-700">
                {formatCurrency(calculation.fairTariff)}
              </div>
              <p className="text-sm text-green-600 mt-1">por m³</p>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-blue-700">Tarifa Atual</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-700">
                {inputs.currentTariff > 0 ? formatCurrency(inputs.currentTariff) : 'Não informado'}
              </div>
              <p className="text-sm text-blue-600 mt-1">por m³</p>
            </CardContent>
          </Card>

          <Card className={`border-2 ${difference > 0 ? 'border-red-200 bg-red-50' : difference < 0 ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-gray-50'}`}>
            <CardHeader>
              <CardTitle className={difference > 0 ? 'text-red-700' : difference < 0 ? 'text-green-700' : 'text-gray-700'}>
                Diferença
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${difference > 0 ? 'text-red-700' : difference < 0 ? 'text-green-700' : 'text-gray-700'}`}>
                {inputs.currentTariff > 0 ? formatCurrency(Math.abs(difference)) : '-'}
              </div>
              <p className={`text-sm mt-1 ${difference > 0 ? 'text-red-600' : difference < 0 ? 'text-green-600' : 'text-gray-600'}`}>
                {inputs.currentTariff > 0 ? `${difference >= 0 ? '+' : ''}${formatNumber(percentageDiff, 1)}%` : '-'}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Detailed Breakdown */}
      {calculation && (
        <Card>
          <CardHeader>
            <CardTitle>Detalhamento do Cálculo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">Componente</th>
                    <th className="text-right py-2">Valor (R$)</th>
                    <th className="text-right py-2">Por m³ (R$)</th>
                    <th className="text-right py-2">% do Total</th>
                  </tr>
                </thead>
                <tbody className="space-y-2">
                  <tr className="border-b">
                    <td className="py-2">Retorno do WACC</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.waccReturn)}</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.waccReturn / inputs.waterVolume)}</td>
                    <td className="text-right">{formatPercentage(calculation.costBreakdown.waccReturn / calculation.totalCosts)}</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">OPEX</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.opex)}</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.opex / inputs.waterVolume)}</td>
                    <td className="text-right">{formatPercentage(calculation.costBreakdown.opex / calculation.totalCosts)}</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">Impostos (PIS + COFINS)</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.taxes)}</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.taxes / inputs.waterVolume)}</td>
                    <td className="text-right">{formatPercentage(calculation.costBreakdown.taxes / calculation.totalCosts)}</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">Depreciação</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.depreciation)}</td>
                    <td className="text-right">{formatCurrency(calculation.costBreakdown.depreciation / inputs.waterVolume)}</td>
                    <td className="text-right">{formatPercentage(calculation.costBreakdown.depreciation / calculation.totalCosts)}</td>
                  </tr>
                  <tr className="border-t-2 font-bold">
                    <td className="py-2">Total</td>
                    <td className="text-right">{formatCurrency(calculation.totalCosts)}</td>
                    <td className="text-right">{formatCurrency(calculation.fairTariff)}</td>
                    <td className="text-right">100,00%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
