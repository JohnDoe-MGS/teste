
'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { formatCurrency } from '@/lib/calculations';

interface TariffComparisonChartProps {
  fairTariff: number;
  currentTariff: number;
}

export default function TariffComparisonChart({ fairTariff, currentTariff }: TariffComparisonChartProps) {
  const data = [
    {
      name: 'Tarifa Atual',
      value: currentTariff || 0,
      type: 'current',
    },
    {
      name: 'Tarifa Justa',
      value: fairTariff,
      type: 'fair',
    },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border text-sm">
          <p className="font-medium">{label}</p>
          <p className="text-blue-600">
            {formatCurrency(payload[0].value)} por m³
          </p>
        </div>
      );
    }
    return null;
  };

  const getBarColor = (type: string) => {
    return type === 'current' ? '#60B5FF' : '#FF9149';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Comparação de Tarifas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 20, right: 30, left: 40, bottom: 40 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name" 
                tickLine={false}
                tick={{ fontSize: 10 }}
                interval="preserveStartEnd"
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10 }}
                tickFormatter={(value) => `R$ ${value.toFixed(2)}`}
                label={{ 
                  value: 'Tarifa (R$/m³)', 
                  angle: -90, 
                  position: 'insideLeft', 
                  style: { textAnchor: 'middle', fontSize: 11 } 
                }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getBarColor(entry.type)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        {currentTariff === 0 && (
          <p className="text-center text-gray-500 text-sm mt-4">
            Digite a tarifa atual da CODEGO para ver a comparação
          </p>
        )}
      </CardContent>
    </Card>
  );
}
