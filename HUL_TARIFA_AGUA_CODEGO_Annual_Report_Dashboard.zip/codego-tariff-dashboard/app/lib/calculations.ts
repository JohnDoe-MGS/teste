
import { TariffInputs, TariffCalculation } from './types';

export function calculateFairTariff(inputs: TariffInputs): TariffCalculation {
  const waccReturn = inputs.wacc * inputs.regulatoryAssetBase;
  const totalCosts = waccReturn + inputs.opex + inputs.taxes + inputs.depreciation;
  const fairTariff = totalCosts / inputs.waterVolume;

  return {
    waccReturn,
    totalCosts,
    fairTariff,
    costBreakdown: {
      waccReturn,
      opex: inputs.opex,
      taxes: inputs.taxes,
      depreciation: inputs.depreciation,
    },
  };
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

export function formatNumber(value: number, decimals = 2): string {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

export function formatPercentage(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'percent',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}
