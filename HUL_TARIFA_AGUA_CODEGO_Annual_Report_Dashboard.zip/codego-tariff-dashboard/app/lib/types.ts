
export interface FinancialData {
  company_info: {
    name: string;
    cnpj: string;
    period: string;
  };
  water_sewage_operations: {
    infrastructure: {
      water_supply_system: {
        gross_value: number;
        accumulated_depreciation: number;
        net_book_value: number;
      };
    };
    operations: {
      water_volume_provided_m3: number;
      revenue_per_m3: number;
      opex_per_m3: number;
    };
  };
  regulatory_calculations: {
    wacc: {
      wacc: number;
    };
  };
  tariff_calculation_inputs: {
    water_volume_m3: number;
    net_regulatory_base: number;
    annual_depreciation: number;
    water_opex: number;
    pis_cofins: number;
    wacc_to_calculate: number;
  };
}

export interface TariffInputs {
  wacc: number;
  regulatoryAssetBase: number;
  opex: number;
  taxes: number;
  depreciation: number;
  waterVolume: number;
  currentTariff: number;
}

export interface TariffCalculation {
  waccReturn: number;
  totalCosts: number;
  fairTariff: number;
  costBreakdown: {
    waccReturn: number;
    opex: number;
    taxes: number;
    depreciation: number;
  };
}
