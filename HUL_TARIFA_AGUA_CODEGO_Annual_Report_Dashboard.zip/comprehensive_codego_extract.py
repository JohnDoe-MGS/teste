#!/usr/bin/env python3
"""
Comprehensive script to extract CODEGO financial data for water tariff calculation
"""

import re
import json
from typing import Dict, List, Any
import sys

def read_pdf_content_safe(file_path: str) -> str:
    """Read the PDF content with proper encoding handling"""
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    
    # If all encodings fail, read as binary and decode with errors='ignore'
    with open(file_path, 'rb') as f:
        return f.read().decode('utf-8', errors='ignore')

def extract_account_data(line: str) -> Dict[str, Any]:
    """Extract account data from a balance sheet line"""
    # Pattern to match account lines: code + name + 4 numeric values
    pattern = r'^(\d+-\d+)\s+(.+?)\s+([\d.,\-]+)\s+([\d.,\-]+)\s+([\d.,\-]+)\s+([\d.,\-]+)\s*$'
    match = re.match(pattern, line.strip())
    
    if not match:
        return None
    
    code, name, saldo_atual, credito, debito, saldo_anterior = match.groups()
    
    try:
        # Convert Brazilian number format to float
        def convert_br_number(num_str):
            # Handle negative numbers
            is_negative = num_str.endswith('-') or num_str.startswith('-')
            num_str = num_str.replace('-', '').strip()
            
            # Convert Brazilian format (1.234.567,89) to float
            if ',' in num_str:
                parts = num_str.split(',')
                integer_part = parts[0].replace('.', '')
                decimal_part = parts[1] if len(parts) > 1 else '00'
                result = float(f"{integer_part}.{decimal_part}")
            else:
                result = float(num_str.replace('.', ''))
            
            return -result if is_negative else result
        
        return {
            "code": code,
            "name": name.strip(),
            "current_balance": convert_br_number(saldo_atual),
            "credit": convert_br_number(credito),
            "debit": convert_br_number(debito),
            "previous_balance": convert_br_number(saldo_anterior)
        }
    except (ValueError, IndexError):
        return None

def categorize_accounts(accounts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Categorize accounts into financial statement categories"""
    
    financial_data = {
        "company_info": {
            "name": "COMPANHIA DE DESENVOLVIMENTO ECONOMICO DE GOIAS-CODEGO",
            "cnpj": "01.285.170/0001-22",
            "period": "01/01/2024 A 31/12/2024"
        },
        "assets": {
            "current_assets": {},
            "non_current_assets": {},
            "cash_and_equivalents": {},
            "accounts_receivable": {},
            "total_assets": 0
        },
        "liabilities": {
            "current_liabilities": {},
            "non_current_liabilities": {},
            "total_liabilities": 0
        },
        "equity": {},
        "revenue": {
            "water_services": {},
            "sewage_services": {},
            "other_services": {},
            "total_revenue": 0
        },
        "expenses": {
            "operating_expenses": {},
            "depreciation": {},
            "taxes": {
                "pis": 0,
                "cofins": 0,
                "other_taxes": {}
            },
            "total_expenses": 0
        },
        "regulatory_data": {
            "water_volume_provided": 6241307,  # m³ as provided
            "unit": "m³"
        },
        "all_accounts": {}
    }
    
    # Keywords for categorization
    water_keywords = ['ÁGUA', 'AGUA', 'ESGOTO', 'SANEAMENTO', 'HIDRICO', 'REDE', 'TUBULAÇÃO', 'ESTAÇÃO', 'TRATAMENTO']
    revenue_keywords = ['RECEITA', 'VENDAS', 'FATURAMENTO']
    expense_keywords = ['DESPESA', 'CUSTO', 'GASTO']
    asset_keywords = ['ATIVO', 'CAIXA', 'BANCO', 'APLICAÇÃO', 'INVESTIMENTO']
    liability_keywords = ['PASSIVO', 'FORNECEDOR', 'OBRIGAÇÃO']
    
    for account in accounts:
        if not account:
            continue
            
        code = account['code']
        name = account['name'].upper()
        
        # Store all accounts
        financial_data["all_accounts"][code] = account
        
        # Categorize by account code structure
        if code.startswith('1-'):
            # Assets
            if 'ATIVO' in name:
                financial_data["assets"]["total_assets"] = account['current_balance']
            elif 'CIRCULANTE' in name:
                financial_data["assets"]["current_assets"]["total"] = account['current_balance']
            elif any(keyword in name for keyword in ['CAIXA', 'BANCO', 'APLICAÇÃO']):
                financial_data["assets"]["cash_and_equivalents"][name] = account
            elif 'CLIENTE' in name or 'RECEBER' in name:
                financial_data["assets"]["accounts_receivable"][name] = account
                
        elif code.startswith('2-'):
            # Liabilities
            if 'PASSIVO' in name:
                financial_data["liabilities"]["total_liabilities"] = account['current_balance']
            elif 'CIRCULANTE' in name:
                financial_data["liabilities"]["current_liabilities"]["total"] = account['current_balance']
                
        elif code.startswith('3-') or code.startswith('4-'):
            # Revenue and Expenses (depending on balance)
            if any(keyword in name for keyword in revenue_keywords):
                if any(keyword in name for keyword in water_keywords):
                    financial_data["revenue"]["water_services"][name] = account
                else:
                    financial_data["revenue"]["other_services"][name] = account
            elif any(keyword in name for keyword in expense_keywords):
                financial_data["expenses"]["operating_expenses"][name] = account
            elif 'DEPRECIA' in name:
                financial_data["expenses"]["depreciation"][name] = account
            elif 'PIS' in name:
                financial_data["expenses"]["taxes"]["pis"] += account['current_balance']
            elif 'COFINS' in name:
                financial_data["expenses"]["taxes"]["cofins"] += account['current_balance']
        
        # Special handling for water/sewage related accounts
        if any(keyword in name for keyword in water_keywords):
            if code not in financial_data.get("water_sewage_specific", {}):
                if "water_sewage_specific" not in financial_data:
                    financial_data["water_sewage_specific"] = {}
                financial_data["water_sewage_specific"][code] = account
    
    return financial_data

def calculate_key_metrics(financial_data: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate key financial metrics for tariff calculation"""
    
    metrics = {
        "wacc_components": {
            "total_debt": 0,
            "total_equity": 0,
            "debt_ratio": 0,
            "equity_ratio": 0,
            "estimated_cost_of_debt": 0.12,  # Estimated 12% for Brazilian utilities
            "estimated_cost_of_equity": 0.15,  # Estimated 15% for Brazilian utilities
            "tax_rate": 0.34,  # Brazilian corporate tax rate (IRPJ + CSLL)
            "wacc": 0
        },
        "regulatory_asset_base": {
            "total_assets": financial_data["assets"]["total_assets"],
            "estimated_water_sewage_assets": 0,
            "accumulated_depreciation": 0,
            "net_regulatory_base": 0
        },
        "opex_summary": {
            "total_operating_expenses": 0,
            "estimated_water_opex": 0,
            "opex_per_m3": 0
        },
        "tax_summary": {
            "pis": financial_data["expenses"]["taxes"]["pis"],
            "cofins": financial_data["expenses"]["taxes"]["cofins"],
            "total_pis_cofins": 0
        }
    }
    
    # Calculate total PIS + COFINS
    metrics["tax_summary"]["total_pis_cofins"] = (
        metrics["tax_summary"]["pis"] + metrics["tax_summary"]["cofins"]
    )
    
    # Estimate water/sewage assets (assuming 60% of total assets for a water utility)
    metrics["regulatory_asset_base"]["estimated_water_sewage_assets"] = (
        financial_data["assets"]["total_assets"] * 0.6
    )
    
    # Calculate total operating expenses
    total_opex = sum(
        account['current_balance'] for account in financial_data["expenses"]["operating_expenses"].values()
        if account['current_balance'] > 0
    )
    metrics["opex_summary"]["total_operating_expenses"] = total_opex
    
    # Estimate water-specific OPEX (assuming 70% for water utility)
    metrics["opex_summary"]["estimated_water_opex"] = total_opex * 0.7
    
    # Calculate OPEX per m³
    if financial_data["regulatory_data"]["water_volume_provided"] > 0:
        metrics["opex_summary"]["opex_per_m3"] = (
            metrics["opex_summary"]["estimated_water_opex"] / 
            financial_data["regulatory_data"]["water_volume_provided"]
        )
    
    # Estimate debt and equity (simplified approach)
    total_liabilities = financial_data["liabilities"]["total_liabilities"]
    total_assets = financial_data["assets"]["total_assets"]
    estimated_equity = total_assets - total_liabilities
    
    metrics["wacc_components"]["total_debt"] = total_liabilities
    metrics["wacc_components"]["total_equity"] = estimated_equity
    
    if total_assets > 0:
        metrics["wacc_components"]["debt_ratio"] = total_liabilities / total_assets
        metrics["wacc_components"]["equity_ratio"] = estimated_equity / total_assets
    
    # Calculate WACC
    debt_ratio = metrics["wacc_components"]["debt_ratio"]
    equity_ratio = metrics["wacc_components"]["equity_ratio"]
    cost_of_debt = metrics["wacc_components"]["estimated_cost_of_debt"]
    cost_of_equity = metrics["wacc_components"]["estimated_cost_of_equity"]
    tax_rate = metrics["wacc_components"]["tax_rate"]
    
    wacc = (debt_ratio * cost_of_debt * (1 - tax_rate)) + (equity_ratio * cost_of_equity)
    metrics["wacc_components"]["wacc"] = wacc
    
    return metrics

def main():
    print("Extracting CODEGO financial data...")
    
    # Read the PDF content
    content = read_pdf_content_safe('/home/ubuntu/Uploads/Balancete122024.pdf')
    
    # Extract all account data
    lines = content.split('\n')
    accounts = []
    
    for line in lines:
        account_data = extract_account_data(line)
        if account_data:
            accounts.append(account_data)
    
    print(f"Extracted {len(accounts)} accounts from balance sheet")
    
    # Categorize accounts
    financial_data = categorize_accounts(accounts)
    
    # Calculate key metrics
    key_metrics = calculate_key_metrics(financial_data)
    financial_data["key_metrics"] = key_metrics
    
    # Save to JSON file
    with open('/home/ubuntu/codego_financial_data.json', 'w', encoding='utf-8') as f:
        json.dump(financial_data, f, indent=2, ensure_ascii=False)
    
    # Print summary
    print("\n=== CODEGO FINANCIAL SUMMARY ===")
    print(f"Company: {financial_data['company_info']['name']}")
    print(f"Period: {financial_data['company_info']['period']}")
    print(f"Total Assets: R$ {financial_data['assets']['total_assets']:,.2f}")
    print(f"Total Liabilities: R$ {financial_data['liabilities']['total_liabilities']:,.2f}")
    print(f"Water Volume Provided: {financial_data['regulatory_data']['water_volume_provided']:,} m³")
    
    print(f"\n=== KEY METRICS FOR TARIFF CALCULATION ===")
    print(f"Estimated WACC: {key_metrics['wacc_components']['wacc']:.2%}")
    print(f"Estimated Water/Sewage Assets: R$ {key_metrics['regulatory_asset_base']['estimated_water_sewage_assets']:,.2f}")
    print(f"Total Operating Expenses: R$ {key_metrics['opex_summary']['total_operating_expenses']:,.2f}")
    print(f"Estimated Water OPEX: R$ {key_metrics['opex_summary']['estimated_water_opex']:,.2f}")
    print(f"OPEX per m³: R$ {key_metrics['opex_summary']['opex_per_m3']:.4f}")
    print(f"PIS: R$ {key_metrics['tax_summary']['pis']:,.2f}")
    print(f"COFINS: R$ {key_metrics['tax_summary']['cofins']:,.2f}")
    print(f"Total PIS + COFINS: R$ {key_metrics['tax_summary']['total_pis_cofins']:,.2f}")
    
    print(f"\nData saved to: /home/ubuntu/codego_financial_data.json")
    
    return financial_data

if __name__ == "__main__":
    main()
