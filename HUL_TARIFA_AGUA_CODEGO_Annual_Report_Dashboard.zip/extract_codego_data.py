#!/usr/bin/env python3
"""
Script to extract and organize CODEGO financial data for water tariff calculation
"""

import re
import json
from typing import Dict, List, Any

def read_pdf_content(file_path: str) -> str:
    """Read the PDF content"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def parse_balance_sheet(content: str) -> Dict[str, Any]:
    """Parse the balance sheet and extract relevant financial data"""
    
    # Initialize data structure
    financial_data = {
        "company_info": {
            "name": "COMPANHIA DE DESENVOLVIMENTO ECONOMICO DE GOIAS-CODEGO",
            "cnpj": "01.285.170/0001-22",
            "period": "01/01/2024 A 31/12/2024"
        },
        "assets": {
            "current_assets": {},
            "non_current_assets": {},
            "total_assets": 0
        },
        "liabilities": {
            "current_liabilities": {},
            "non_current_liabilities": {},
            "total_liabilities": 0
        },
        "equity": {},
        "revenue": {
            "water_services": {},
            "sewage_services": {},
            "other_services": {}
        },
        "expenses": {
            "operating_expenses": {},
            "depreciation": {},
            "taxes": {
                "pis": 0,
                "cofins": 0
            }
        },
        "cash_and_equivalents": {},
        "regulatory_data": {
            "water_volume_provided": 6241307,  # m³ as provided
            "unit": "m³"
        }
    }
    
    lines = content.split('\n')
    current_section = ""
    
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
            
        # Extract main account categories and values
        if re.match(r'^\d+-\d+', line):
            parts = line.split()
            if len(parts) >= 5:
                try:
                    code = parts[0]
                    # Find the account name (everything between code and first number)
                    name_start = line.find(parts[0]) + len(parts[0])
                    name_end = line.rfind(parts[-4])  # Find last occurrence of 4th from end
                    account_name = line[name_start:name_end].strip()
                    
                    # Extract financial values (last 4 columns)
                    saldo_atual = float(parts[-4].replace('.', '').replace(',', '.'))
                    credito = float(parts[-3].replace('.', '').replace(',', '.'))
                    debito = float(parts[-2].replace('.', '').replace(',', '.'))
                    saldo_anterior = float(parts[-1].replace('.', '').replace(',', '.'))
                    
                    account_data = {
                        "code": code,
                        "name": account_name,
                        "current_balance": saldo_atual,
                        "credit": credito,
                        "debit": debito,
                        "previous_balance": saldo_anterior
                    }
                    
                    # Categorize accounts based on code and name
                    if code.startswith('1-'):
                        if 'ATIVO' in account_name.upper():
                            financial_data["assets"]["total_assets"] = saldo_atual
                        elif 'CIRCULANTE' in account_name.upper():
                            financial_data["assets"]["current_assets"]["total"] = saldo_atual
                        elif 'CAIXA' in account_name.upper() or 'BANCO' in account_name.upper():
                            financial_data["cash_and_equivalents"][account_name] = account_data
                            
                    elif code.startswith('2-'):
                        if 'PASSIVO' in account_name.upper():
                            financial_data["liabilities"]["total_liabilities"] = saldo_atual
                        elif 'CIRCULANTE' in account_name.upper():
                            financial_data["liabilities"]["current_liabilities"]["total"] = saldo_atual
                            
                    # Look for water and sewage related accounts
                    if any(keyword in account_name.upper() for keyword in ['ÁGUA', 'AGUA', 'ESGOTO', 'SANEAMENTO', 'HIDRICO']):
                        if 'RECEITA' in account_name.upper() or 'VENDAS' in account_name.upper():
                            financial_data["revenue"]["water_services"][account_name] = account_data
                        elif 'DESPESA' in account_name.upper() or 'CUSTO' in account_name.upper():
                            financial_data["expenses"]["operating_expenses"][account_name] = account_data
                        elif 'DEPRECIA' in account_name.upper():
                            financial_data["expenses"]["depreciation"][account_name] = account_data
                            
                    # Look for tax accounts (PIS and COFINS)
                    if 'PIS' in account_name.upper():
                        financial_data["expenses"]["taxes"]["pis"] += saldo_atual
                    elif 'COFINS' in account_name.upper():
                        financial_data["expenses"]["taxes"]["cofins"] += saldo_atual
                        
                    # Look for depreciation accounts
                    if 'DEPRECIA' in account_name.upper():
                        financial_data["expenses"]["depreciation"][account_name] = account_data
                        
                except (ValueError, IndexError) as e:
                    continue
                    
        # Look for specific revenue and expense items in the text
        elif 'RECEITA' in line.upper() and any(keyword in line.upper() for keyword in ['ÁGUA', 'AGUA', 'ESGOTO']):
            # Extract revenue information
            pass
        elif 'DESPESA' in line.upper() or 'CUSTO' in line.upper():
            # Extract expense information
            pass
    
    return financial_data

def identify_water_sewage_assets(financial_data: Dict[str, Any]) -> Dict[str, Any]:
    """Identify assets specifically related to water and sewage infrastructure"""
    
    water_sewage_assets = {
        "infrastructure": {},
        "equipment": {},
        "intangible": {},
        "total_value": 0
    }
    
    # Keywords to identify water/sewage related assets
    water_keywords = ['ÁGUA', 'AGUA', 'ESGOTO', 'SANEAMENTO', 'HIDRICO', 'REDE', 'TUBULAÇÃO', 'ESTAÇÃO', 'TRATAMENTO']
    
    # This would need to be expanded based on the full document content
    # For now, we'll create a placeholder structure
    
    return water_sewage_assets

def calculate_regulatory_metrics(financial_data: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate metrics needed for WACC and regulatory asset base"""
    
    metrics = {
        "wacc_components": {
            "debt_ratio": 0,
            "equity_ratio": 0,
            "cost_of_debt": 0,
            "cost_of_equity": 0,
            "tax_rate": 0,
            "wacc": 0
        },
        "regulatory_asset_base": {
            "gross_assets": 0,
            "accumulated_depreciation": 0,
            "net_assets": 0
        },
        "opex": {
            "total_operating_expenses": 0,
            "water_specific_opex": 0
        }
    }
    
    return metrics

def main():
    # Read the PDF content
    content = read_pdf_content('/home/ubuntu/Uploads/Balancete122024.pdf')
    
    # Parse the balance sheet
    financial_data = parse_balance_sheet(content)
    
    # Identify water and sewage specific assets
    water_sewage_assets = identify_water_sewage_assets(financial_data)
    financial_data["water_sewage_assets"] = water_sewage_assets
    
    # Calculate regulatory metrics
    regulatory_metrics = calculate_regulatory_metrics(financial_data)
    financial_data["regulatory_metrics"] = regulatory_metrics
    
    # Save to JSON file
    with open('/home/ubuntu/codego_financial_data.json', 'w', encoding='utf-8') as f:
        json.dump(financial_data, f, indent=2, ensure_ascii=False)
    
    print("Financial data extracted and saved to codego_financial_data.json")
    print(f"Total assets identified: R$ {financial_data['assets']['total_assets']:,.2f}")
    print(f"Water volume provided: {financial_data['regulatory_data']['water_volume_provided']:,} m³")
    
    return financial_data

if __name__ == "__main__":
    main()
