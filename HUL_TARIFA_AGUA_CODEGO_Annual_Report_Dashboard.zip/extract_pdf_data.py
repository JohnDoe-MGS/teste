#!/usr/bin/env python3
"""
Extract CODEGO financial data from PDF using proper PDF parsing
"""

import pdfplumber
import re
import json
from typing import Dict, List, Any

def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract text from PDF using pdfplumber"""
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        print(f"Error extracting PDF: {e}")
        return ""
    return text

def convert_br_number(num_str: str) -> float:
    """Convert Brazilian number format to float"""
    if not num_str or num_str.strip() == '':
        return 0.0
    
    # Handle negative numbers
    is_negative = num_str.strip().endswith('-') or num_str.strip().startswith('-')
    num_str = num_str.replace('-', '').strip()
    
    # Remove any non-numeric characters except . and ,
    num_str = re.sub(r'[^\d.,]', '', num_str)
    
    if not num_str:
        return 0.0
    
    try:
        # Convert Brazilian format (1.234.567,89) to float
        if ',' in num_str:
            parts = num_str.split(',')
            integer_part = parts[0].replace('.', '')
            decimal_part = parts[1] if len(parts) > 1 else '00'
            result = float(f"{integer_part}.{decimal_part}")
        else:
            result = float(num_str.replace('.', ''))
        
        return -result if is_negative else result
    except ValueError:
        return 0.0

def parse_balance_sheet_line(line: str) -> Dict[str, Any]:
    """Parse a balance sheet line to extract account information"""
    line = line.strip()
    if not line:
        return None
    
    # Look for lines with account codes (format: X-XXXXXX or X-XXXXXXXXX)
    code_pattern = r'^(\d+-\d+)\s+'
    match = re.match(code_pattern, line)
    
    if not match:
        return None
    
    code = match.group(1)
    rest_of_line = line[match.end():].strip()
    
    # Split the rest of the line to find the account name and numbers
    # The format appears to be: CODE NAME VALUE1 VALUE2 VALUE3 VALUE4
    parts = rest_of_line.split()
    
    if len(parts) < 4:  # Need at least 4 numeric values
        return None
    
    # Find where the numbers start (last 4 parts should be numbers)
    numeric_parts = []
    name_parts = []
    
    # Work backwards to find the 4 numeric values
    for i in range(len(parts) - 1, -1, -1):
        part = parts[i]
        # Check if this looks like a number (contains digits, commas, dots, or minus)
        if re.match(r'^[\d.,-]+$', part):
            numeric_parts.insert(0, part)
            if len(numeric_parts) == 4:
                name_parts = parts[:i]
                break
        else:
            break
    
    if len(numeric_parts) != 4:
        return None
    
    account_name = ' '.join(name_parts)
    
    try:
        saldo_atual = convert_br_number(numeric_parts[0])
        credito = convert_br_number(numeric_parts[1])
        debito = convert_br_number(numeric_parts[2])
        saldo_anterior = convert_br_number(numeric_parts[3])
        
        return {
            "code": code,
            "name": account_name,
            "current_balance": saldo_atual,
            "credit": credito,
            "debit": debito,
            "previous_balance": saldo_anterior
        }
    except Exception as e:
        return None

def categorize_accounts(accounts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Categorize accounts into financial statement categories"""
    
    financial_data = {
        "company_info": {
            "name": "COMPANHIA DE DESENVOLVIMENTO ECONOMICO DE GOIAS-CODEGO",
            "cnpj": "01.285.170/0001-22",
            "period": "01/01/2024 A 31/12/2024"
        },
        "assets": {
            "current_assets": {},
            "non_current_assets": {},
            "cash_and_equivalents": {},
            "accounts_receivable": {},
            "total_assets": 0
        },
        "liabilities": {
            "current_liabilities": {},
            "non_current_liabilities": {},
            "total_liabilities": 0
        },
        "equity": {},
        "revenue": {
            "water_services": {},
            "sewage_services": {},
            "other_services": {},
            "total_revenue": 0
        },
        "expenses": {
            "operating_expenses": {},
            "depreciation": {},
            "taxes": {
                "pis": 0,
                "cofins": 0,
                "other_taxes": {}
            },
            "total_expenses": 0
        },
        "regulatory_data": {
            "water_volume_provided": 6241307,  # m³ as provided
            "unit": "m³"
        },
        "all_accounts": {},
        "water_sewage_specific": {}
    }
    
    # Keywords for categorization
    water_keywords = ['ÁGUA', 'AGUA', 'ESGOTO', 'SANEAMENTO', 'HIDRICO', 'REDE', 'TUBULAÇÃO', 'ESTAÇÃO', 'TRATAMENTO']
    
    for account in accounts:
        if not account:
            continue
            
        code = account['code']
        name = account['name'].upper()
        
        # Store all accounts
        financial_data["all_accounts"][code] = account
        
        # Categorize by account code structure and name
        if code.startswith('1-'):
            # Assets
            if 'ATIVO' in name:
                financial_data["assets"]["total_assets"] = account['current_balance']
            elif 'CIRCULANTE' in name:
                financial_data["assets"]["current_assets"]["total"] = account['current_balance']
            elif any(keyword in name for keyword in ['CAIXA', 'BANCO', 'APLICAÇÃO', 'NUMERARIO']):
                financial_data["assets"]["cash_and_equivalents"][name] = account
            elif 'CLIENTE' in name or 'RECEBER' in name or 'CREDITO' in name:
                financial_data["assets"]["accounts_receivable"][name] = account
                
        elif code.startswith('2-'):
            # Liabilities
            if 'PASSIVO' in name:
                financial_data["liabilities"]["total_liabilities"] = account['current_balance']
            elif 'CIRCULANTE' in name:
                financial_data["liabilities"]["current_liabilities"]["total"] = account['current_balance']
                
        elif code.startswith('3-') or code.startswith('4-'):
            # Revenue and Expenses
            if 'RECEITA' in name or 'VENDAS' in name or 'FATURAMENTO' in name:
                if any(keyword in name for keyword in water_keywords):
                    financial_data["revenue"]["water_services"][name] = account
                else:
                    financial_data["revenue"]["other_services"][name] = account
            elif 'DESPESA' in name or 'CUSTO' in name or 'GASTO' in name:
                financial_data["expenses"]["operating_expenses"][name] = account
            elif 'DEPRECIA' in name:
                financial_data["expenses"]["depreciation"][name] = account
            elif 'PIS' in name:
                financial_data["expenses"]["taxes"]["pis"] += account['current_balance']
                financial_data["expenses"]["taxes"]["other_taxes"][name] = account
            elif 'COFINS' in name:
                financial_data["expenses"]["taxes"]["cofins"] += account['current_balance']
                financial_data["expenses"]["taxes"]["other_taxes"][name] = account
        
        # Special handling for water/sewage related accounts
        if any(keyword in name for keyword in water_keywords):
            financial_data["water_sewage_specific"][code] = account
    
    return financial_data

def calculate_key_metrics(financial_data: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate key financial metrics for tariff calculation"""
    
    # Calculate totals
    total_cash = sum(
        account['current_balance'] for account in financial_data["assets"]["cash_and_equivalents"].values()
        if account['current_balance'] > 0
    )
    
    total_receivables = sum(
        account['current_balance'] for account in financial_data["assets"]["accounts_receivable"].values()
        if account['current_balance'] > 0
    )
    
    total_revenue = sum(
        account['current_balance'] for account in financial_data["revenue"]["water_services"].values()
        if account['current_balance'] > 0
    ) + sum(
        account['current_balance'] for account in financial_data["revenue"]["other_services"].values()
        if account['current_balance'] > 0
    )
    
    total_opex = sum(
        account['current_balance'] for account in financial_data["expenses"]["operating_expenses"].values()
        if account['current_balance'] > 0
    )
    
    total_depreciation = sum(
        account['current_balance'] for account in financial_data["expenses"]["depreciation"].values()
        if account['current_balance'] > 0
    )
    
    metrics = {
        "summary": {
            "total_cash_and_equivalents": total_cash,
            "total_accounts_receivable": total_receivables,
            "total_revenue": total_revenue,
            "total_operating_expenses": total_opex,
            "total_depreciation": total_depreciation
        },
        "wacc_components": {
            "total_debt": financial_data["liabilities"]["total_liabilities"],
            "total_assets": financial_data["assets"]["total_assets"],
            "estimated_equity": financial_data["assets"]["total_assets"] - financial_data["liabilities"]["total_liabilities"],
            "debt_ratio": 0,
            "equity_ratio": 0,
            "estimated_cost_of_debt": 0.12,  # 12% estimated for Brazilian utilities
            "estimated_cost_of_equity": 0.15,  # 15% estimated for Brazilian utilities
            "tax_rate": 0.34,  # Brazilian corporate tax rate
            "wacc": 0
        },
        "regulatory_asset_base": {
            "total_assets": financial_data["assets"]["total_assets"],
            "estimated_water_sewage_assets": 0,
            "accumulated_depreciation": total_depreciation,
            "net_regulatory_base": 0
        },
        "opex_summary": {
            "total_operating_expenses": total_opex,
            "estimated_water_opex": total_opex * 0.7,  # Assuming 70% for water services
            "opex_per_m3": 0
        },
        "tax_summary": {
            "pis": financial_data["expenses"]["taxes"]["pis"],
            "cofins": financial_data["expenses"]["taxes"]["cofins"],
            "total_pis_cofins": financial_data["expenses"]["taxes"]["pis"] + financial_data["expenses"]["taxes"]["cofins"]
        }
    }
    
    # Calculate ratios
    if financial_data["assets"]["total_assets"] > 0:
        metrics["wacc_components"]["debt_ratio"] = financial_data["liabilities"]["total_liabilities"] / financial_data["assets"]["total_assets"]
        metrics["wacc_components"]["equity_ratio"] = metrics["wacc_components"]["estimated_equity"] / financial_data["assets"]["total_assets"]
    
    # Calculate WACC
    debt_ratio = metrics["wacc_components"]["debt_ratio"]
    equity_ratio = metrics["wacc_components"]["equity_ratio"]
    cost_of_debt = metrics["wacc_components"]["estimated_cost_of_debt"]
    cost_of_equity = metrics["wacc_components"]["estimated_cost_of_equity"]
    tax_rate = metrics["wacc_components"]["tax_rate"]
    
    wacc = (debt_ratio * cost_of_debt * (1 - tax_rate)) + (equity_ratio * cost_of_equity)
    metrics["wacc_components"]["wacc"] = wacc
    
    # Estimate water/sewage assets (60% of total assets for water utility)
    metrics["regulatory_asset_base"]["estimated_water_sewage_assets"] = financial_data["assets"]["total_assets"] * 0.6
    metrics["regulatory_asset_base"]["net_regulatory_base"] = metrics["regulatory_asset_base"]["estimated_water_sewage_assets"] - total_depreciation
    
    # Calculate OPEX per m³
    if financial_data["regulatory_data"]["water_volume_provided"] > 0:
        metrics["opex_summary"]["opex_per_m3"] = metrics["opex_summary"]["estimated_water_opex"] / financial_data["regulatory_data"]["water_volume_provided"]
    
    return metrics

def main():
    print("Extracting CODEGO financial data from PDF...")
    
    # Extract text from PDF
    pdf_text = extract_text_from_pdf('/home/ubuntu/Uploads/Balancete122024.pdf')
    
    if not pdf_text:
        print("Failed to extract text from PDF")
        return
    
    print(f"Extracted {len(pdf_text)} characters from PDF")
    
    # Parse account lines
    lines = pdf_text.split('\n')
    accounts = []
    
    for line in lines:
        account_data = parse_balance_sheet_line(line)
        if account_data:
            accounts.append(account_data)
    
    print(f"Extracted {len(accounts)} accounts from balance sheet")
    
    if len(accounts) == 0:
        print("No accounts found. Let's examine the first few lines:")
        for i, line in enumerate(lines[:20]):
            if line.strip():
                print(f"Line {i+1}: {line}")
        return
    
    # Categorize accounts
    financial_data = categorize_accounts(accounts)
    
    # Calculate key metrics
    key_metrics = calculate_key_metrics(financial_data)
    financial_data["key_metrics"] = key_metrics
    
    # Save to JSON file
    with open('/home/ubuntu/codego_financial_data.json', 'w', encoding='utf-8') as f:
        json.dump(financial_data, f, indent=2, ensure_ascii=False)
    
    # Print summary
    print("\n=== CODEGO FINANCIAL SUMMARY ===")
    print(f"Company: {financial_data['company_info']['name']}")
    print(f"Period: {financial_data['company_info']['period']}")
    print(f"Total Assets: R$ {financial_data['assets']['total_assets']:,.2f}")
    print(f"Total Liabilities: R$ {financial_data['liabilities']['total_liabilities']:,.2f}")
    print(f"Water Volume Provided: {financial_data['regulatory_data']['water_volume_provided']:,} m³")
    
    print(f"\n=== EXTRACTED DATA SUMMARY ===")
    print(f"Cash and Equivalents Accounts: {len(financial_data['assets']['cash_and_equivalents'])}")
    print(f"Accounts Receivable: {len(financial_data['assets']['accounts_receivable'])}")
    print(f"Revenue Accounts: {len(financial_data['revenue']['water_services']) + len(financial_data['revenue']['other_services'])}")
    print(f"Expense Accounts: {len(financial_data['expenses']['operating_expenses'])}")
    print(f"Water/Sewage Specific Accounts: {len(financial_data['water_sewage_specific'])}")
    
    print(f"\n=== KEY METRICS FOR TARIFF CALCULATION ===")
    print(f"Total Cash & Equivalents: R$ {key_metrics['summary']['total_cash_and_equivalents']:,.2f}")
    print(f"Total Accounts Receivable: R$ {key_metrics['summary']['total_accounts_receivable']:,.2f}")
    print(f"Estimated WACC: {key_metrics['wacc_components']['wacc']:.2%}")
    print(f"Estimated Water/Sewage Assets: R$ {key_metrics['regulatory_asset_base']['estimated_water_sewage_assets']:,.2f}")
    print(f"Total Operating Expenses: R$ {key_metrics['opex_summary']['total_operating_expenses']:,.2f}")
    print(f"Estimated Water OPEX: R$ {key_metrics['opex_summary']['estimated_water_opex']:,.2f}")
    print(f"OPEX per m³: R$ {key_metrics['opex_summary']['opex_per_m3']:.4f}")
    print(f"PIS: R$ {key_metrics['tax_summary']['pis']:,.2f}")
    print(f"COFINS: R$ {key_metrics['tax_summary']['cofins']:,.2f}")
    print(f"Total PIS + COFINS: R$ {key_metrics['tax_summary']['total_pis_cofins']:,.2f}")
    
    print(f"\nData saved to: /home/ubuntu/codego_financial_data.json")
    
    return financial_data

if __name__ == "__main__":
    main()
