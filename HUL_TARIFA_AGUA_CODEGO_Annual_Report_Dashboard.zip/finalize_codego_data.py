#!/usr/bin/env python3
"""
Finalize CODEGO financial data with correct totals and comprehensive analysis
"""

import json
from typing import Dict, Any

def finalize_financial_data():
    """Load and finalize the financial data with correct calculations"""
    
    with open('/home/ubuntu/codego_financial_data.json', 'r') as f:
        data = json.load(f)
    
    # Extract key financial metrics from the accounts
    all_accounts = data['all_accounts']
    
    # Find main balance sheet totals
    total_assets = 0
    total_liabilities = 0
    
    # Key accounts identified
    key_accounts = {
        "capital_social_total": 1000000000.00,  # 3-280000000
        "capital_integralizado": 420447038.10,  # 4-280000001
        "capital_a_integralizar": -579552961.90,  # 3-281000000
        "prejuizos_acumulados": -266304669.55,  # 4-283000002
        "ativo_longo_prazo": 101111493.55,  # 1-121000000
        "vendas_servicos": 13695171.23,  # 3-102000000
        "vendas_terrenos": 25989.35,  # 3-102200000
        "vendas_a_escriturar": 6734533.52,  # 4-202100002
        "sistema_agua_esgoto": 32348071.63,  # 3-127600000
        "sistema_agua_esgoto_imobilizar": 32348071.63,  # 4-127600001
        "sistema_agua_esgoto_depreciacao": -32344398.55,  # 4-127900006
        "saneago_receivable": 1428394.47,  # 4-102000375 (SANEAGO)
        "adiantamento_clientes_agua": 49631.94,  # 4-202100001
        "jaragua": 544271.69,  # 4-107300001
        "sao_miguel_araguaia": 18000.00,  # 4-122000019
    }
    
    # Calculate estimated total assets and liabilities
    # Based on the capital structure and long-term assets
    estimated_total_assets = (
        data['assets']['cash_and_equivalents']['CAIXA E EQUIVALENTE DE CAIXA']['current_balance'] +
        key_accounts['ativo_longo_prazo'] +
        data['assets']['accounts_receivable']['CREDITOS']['current_balance'] +
        data['assets']['accounts_receivable']['OUTROS CREDITOS']['current_balance'] +
        abs(key_accounts['sistema_agua_esgoto'])  # Water and sewage infrastructure
    )
    
    estimated_equity = key_accounts['capital_integralizado'] + key_accounts['prejuizos_acumulados']
    estimated_total_liabilities = estimated_total_assets - estimated_equity
    
    # Update the financial data structure
    updated_data = {
        "company_info": data['company_info'],
        "balance_sheet": {
            "assets": {
                "current_assets": {
                    "cash_and_equivalents": 55786378.57,
                    "accounts_receivable": 3601184.50,
                    "other_current_assets": data['expenses']['operating_expenses']['DESPESAS PAGAS ANTECIPAMENTE']['current_balance'],
                    "total_current_assets": 55786378.57 + 3601184.50 + 95122.76
                },
                "non_current_assets": {
                    "long_term_assets": key_accounts['ativo_longo_prazo'],
                    "water_sewage_infrastructure": {
                        "gross_value": key_accounts['sistema_agua_esgoto'],
                        "accumulated_depreciation": key_accounts['sistema_agua_esgoto_depreciacao'],
                        "net_value": key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao']
                    },
                    "total_non_current_assets": key_accounts['ativo_longo_prazo'] + (key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao'])
                },
                "total_assets": estimated_total_assets
            },
            "liabilities": {
                "current_liabilities": {
                    "customer_advances": key_accounts['adiantamento_clientes_agua'],
                    "other_current_liabilities": 0,
                    "total_current_liabilities": key_accounts['adiantamento_clientes_agua']
                },
                "non_current_liabilities": {
                    "estimated_long_term_debt": max(0, estimated_total_liabilities - key_accounts['adiantamento_clientes_agua']),
                    "total_non_current_liabilities": max(0, estimated_total_liabilities - key_accounts['adiantamento_clientes_agua'])
                },
                "total_liabilities": estimated_total_liabilities
            },
            "equity": {
                "capital_social": key_accounts['capital_integralizado'],
                "capital_a_integralizar": key_accounts['capital_a_integralizar'],
                "accumulated_losses": key_accounts['prejuizos_acumulados'],
                "total_equity": estimated_equity
            }
        },
        "income_statement": {
            "revenue": {
                "water_services": {
                    "service_sales": key_accounts['vendas_servicos'],
                    "sales_to_record": key_accounts['vendas_a_escriturar'],
                    "total_water_revenue": key_accounts['vendas_servicos'] + key_accounts['vendas_a_escriturar']
                },
                "other_revenue": {
                    "land_sales": key_accounts['vendas_terrenos'],
                    "total_other_revenue": key_accounts['vendas_terrenos']
                },
                "total_revenue": key_accounts['vendas_servicos'] + key_accounts['vendas_a_escriturar'] + key_accounts['vendas_terrenos']
            },
            "expenses": {
                "operating_expenses": {
                    "total_opex": data['key_metrics']['opex_summary']['total_operating_expenses'],
                    "estimated_water_opex": data['key_metrics']['opex_summary']['estimated_water_opex']
                },
                "depreciation": {
                    "water_sewage_depreciation": abs(key_accounts['sistema_agua_esgoto_depreciacao']),
                    "total_depreciation": data['key_metrics']['summary']['total_depreciation']
                },
                "taxes": {
                    "pis": data['key_metrics']['tax_summary']['pis'],
                    "cofins": data['key_metrics']['tax_summary']['cofins'],
                    "total_pis_cofins": data['key_metrics']['tax_summary']['total_pis_cofins']
                }
            }
        },
        "water_sewage_operations": {
            "infrastructure": {
                "water_supply_system": {
                    "gross_value": key_accounts['sistema_agua_esgoto'],
                    "accumulated_depreciation": key_accounts['sistema_agua_esgoto_depreciacao'],
                    "net_book_value": key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao']
                },
                "total_infrastructure_net": key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao']
            },
            "operations": {
                "water_volume_provided_m3": 6241307,
                "revenue_per_m3": (key_accounts['vendas_servicos'] + key_accounts['vendas_a_escriturar']) / 6241307,
                "opex_per_m3": data['key_metrics']['opex_summary']['opex_per_m3']
            },
            "receivables": {
                "saneago": key_accounts['saneago_receivable'],
                "jaragua": key_accounts['jaragua'],
                "sao_miguel_araguaia": key_accounts['sao_miguel_araguaia'],
                "customer_advances": key_accounts['adiantamento_clientes_agua']
            }
        },
        "regulatory_calculations": {
            "wacc": {
                "debt_ratio": estimated_total_liabilities / estimated_total_assets if estimated_total_assets > 0 else 0,
                "equity_ratio": estimated_equity / estimated_total_assets if estimated_total_assets > 0 else 0,
                "cost_of_debt": 0.12,  # 12% estimated
                "cost_of_equity": 0.15,  # 15% estimated
                "tax_rate": 0.34,  # 34% Brazilian corporate tax
                "wacc": 0
            },
            "regulatory_asset_base": {
                "water_sewage_assets_gross": key_accounts['sistema_agua_esgoto'],
                "accumulated_depreciation": abs(key_accounts['sistema_agua_esgoto_depreciacao']),
                "net_regulatory_base": key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao'],
                "percentage_of_total_assets": (key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao']) / estimated_total_assets if estimated_total_assets > 0 else 0
            },
            "opex": {
                "total_operating_expenses": data['key_metrics']['opex_summary']['total_operating_expenses'],
                "estimated_water_opex": data['key_metrics']['opex_summary']['estimated_water_opex'],
                "water_opex_percentage": 0.7  # Assumed 70% for water services
            },
            "taxes": {
                "pis_rate": 0.0165,  # 1.65%
                "cofins_rate": 0.076,  # 7.6%
                "total_pis_cofins": data['key_metrics']['tax_summary']['total_pis_cofins']
            }
        },
        "tariff_calculation_inputs": {
            "water_volume_m3": 6241307,
            "net_regulatory_base": key_accounts['sistema_agua_esgoto'] + key_accounts['sistema_agua_esgoto_depreciacao'],
            "annual_depreciation": abs(key_accounts['sistema_agua_esgoto_depreciacao']),
            "water_opex": data['key_metrics']['opex_summary']['estimated_water_opex'],
            "pis_cofins": data['key_metrics']['tax_summary']['total_pis_cofins'],
            "wacc_to_calculate": 0  # Will be calculated below
        }
    }
    
    # Calculate WACC
    debt_ratio = updated_data['regulatory_calculations']['wacc']['debt_ratio']
    equity_ratio = updated_data['regulatory_calculations']['wacc']['equity_ratio']
    cost_of_debt = updated_data['regulatory_calculations']['wacc']['cost_of_debt']
    cost_of_equity = updated_data['regulatory_calculations']['wacc']['cost_of_equity']
    tax_rate = updated_data['regulatory_calculations']['wacc']['tax_rate']
    
    wacc = (debt_ratio * cost_of_debt * (1 - tax_rate)) + (equity_ratio * cost_of_equity)
    updated_data['regulatory_calculations']['wacc']['wacc'] = wacc
    updated_data['tariff_calculation_inputs']['wacc_to_calculate'] = wacc
    
    # Save the finalized data
    with open('/home/ubuntu/codego_financial_data.json', 'w', encoding='utf-8') as f:
        json.dump(updated_data, f, indent=2, ensure_ascii=False)
    
    return updated_data

def print_summary(data):
    """Print a comprehensive summary of the financial data"""
    
    print("=" * 80)
    print("CODEGO - COMPANHIA DE DESENVOLVIMENTO ECONOMICO DE GOIAS")
    print("FINANCIAL ANALYSIS FOR WATER TARIFF CALCULATION - 2024")
    print("=" * 80)
    
    print(f"\n📊 BALANCE SHEET SUMMARY")
    print(f"Total Assets: R$ {data['balance_sheet']['assets']['total_assets']:,.2f}")
    print(f"Total Liabilities: R$ {data['balance_sheet']['liabilities']['total_liabilities']:,.2f}")
    print(f"Total Equity: R$ {data['balance_sheet']['equity']['total_equity']:,.2f}")
    
    print(f"\n💰 CASH AND LIQUIDITY")
    print(f"Cash and Equivalents: R$ {data['balance_sheet']['assets']['current_assets']['cash_and_equivalents']:,.2f}")
    print(f"Accounts Receivable: R$ {data['balance_sheet']['assets']['current_assets']['accounts_receivable']:,.2f}")
    
    print(f"\n🚰 WATER & SEWAGE INFRASTRUCTURE")
    print(f"Gross Infrastructure Value: R$ {data['water_sewage_operations']['infrastructure']['water_supply_system']['gross_value']:,.2f}")
    print(f"Accumulated Depreciation: R$ {data['water_sewage_operations']['infrastructure']['water_supply_system']['accumulated_depreciation']:,.2f}")
    print(f"Net Book Value: R$ {data['water_sewage_operations']['infrastructure']['water_supply_system']['net_book_value']:,.2f}")
    
    print(f"\n📈 REVENUE ANALYSIS")
    print(f"Total Water Revenue: R$ {data['income_statement']['revenue']['water_services']['total_water_revenue']:,.2f}")
    print(f"Water Volume Provided: {data['water_sewage_operations']['operations']['water_volume_provided_m3']:,} m³")
    print(f"Revenue per m³: R$ {data['water_sewage_operations']['operations']['revenue_per_m3']:.4f}")
    
    print(f"\n💸 OPERATING EXPENSES")
    print(f"Total Operating Expenses: R$ {data['income_statement']['expenses']['operating_expenses']['total_opex']:,.2f}")
    print(f"Estimated Water OPEX: R$ {data['income_statement']['expenses']['operating_expenses']['estimated_water_opex']:,.2f}")
    print(f"OPEX per m³: R$ {data['water_sewage_operations']['operations']['opex_per_m3']:.4f}")
    
    print(f"\n🏛️ TAXES")
    print(f"PIS: R$ {data['income_statement']['expenses']['taxes']['pis']:,.2f}")
    print(f"COFINS: R$ {data['income_statement']['expenses']['taxes']['cofins']:,.2f}")
    print(f"Total PIS + COFINS: R$ {data['income_statement']['expenses']['taxes']['total_pis_cofins']:,.2f}")
    
    print(f"\n📊 REGULATORY METRICS FOR TARIFF CALCULATION")
    print(f"WACC (Weighted Average Cost of Capital): {data['regulatory_calculations']['wacc']['wacc']:.2%}")
    print(f"  - Debt Ratio: {data['regulatory_calculations']['wacc']['debt_ratio']:.2%}")
    print(f"  - Equity Ratio: {data['regulatory_calculations']['wacc']['equity_ratio']:.2%}")
    print(f"  - Cost of Debt: {data['regulatory_calculations']['wacc']['cost_of_debt']:.2%}")
    print(f"  - Cost of Equity: {data['regulatory_calculations']['wacc']['cost_of_equity']:.2%}")
    
    print(f"\nRegulatory Asset Base (RAB):")
    print(f"  - Net Regulatory Base: R$ {data['regulatory_calculations']['regulatory_asset_base']['net_regulatory_base']:,.2f}")
    print(f"  - Annual Depreciation: R$ {data['tariff_calculation_inputs']['annual_depreciation']:,.2f}")
    
    print(f"\n🎯 KEY INPUTS FOR FAIR WATER TARIFF CALCULATION")
    print(f"1. Water Volume: {data['tariff_calculation_inputs']['water_volume_m3']:,} m³")
    print(f"2. Net Regulatory Asset Base: R$ {data['tariff_calculation_inputs']['net_regulatory_base']:,.2f}")
    print(f"3. Annual Water OPEX: R$ {data['tariff_calculation_inputs']['water_opex']:,.2f}")
    print(f"4. Annual Depreciation: R$ {data['tariff_calculation_inputs']['annual_depreciation']:,.2f}")
    print(f"5. PIS + COFINS: R$ {data['tariff_calculation_inputs']['pis_cofins']:,.2f}")
    print(f"6. WACC: {data['tariff_calculation_inputs']['wacc_to_calculate']:.2%}")
    
    print(f"\n" + "=" * 80)
    print("Data successfully extracted and organized for tariff calculation!")
    print("File saved as: /home/ubuntu/codego_financial_data.json")
    print("=" * 80)

def main():
    data = finalize_financial_data()
    print_summary(data)
    return data

if __name__ == "__main__":
    main()
